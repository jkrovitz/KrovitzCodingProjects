import java.awt.*;
import javax.swing.*;
import java.awt.Color;

/*
 * Jeremy Krovitz
 * CSci 1130-91
 * Summer 2017
 * This program is an applet that will displays
 * seven smiley faces of different sizes at
 * random locations.
 */
public class SmileyFaces extends JApplet {
    //Declaring my instance variables here.
    private int locX;
    private int locY;
    private int size;
    private int Min;
    private int Max;

    /**
     * In the init() method the background is set and the variables
     * Max and Min are assigned.
     */
    public void init() {
        Max = 150;
        Min = 25;
        makeRandomColor();
    }


    /**
     * This is the paint method, which allows shapes, text,
     * images, etc. to be drawn to the applet.
     * @param g This is an instance of the Graphics class.
     */
    public void paint(Graphics g) {

        //Call the parent class.
        super.paint(g);

        //Anti-aliasing is done here.
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        //Call getImage to load image; call getCodeBase to
        //specify location where running applet.
        Image img = getImage(getCodeBase(), "NightSky.jpg");

        //Call drawImage to draw the image onto the applet.
        g2d.drawImage(img, 0, 0, getWidth(), getHeight(), this);

        /* Make seven calls to randomizeSmileySizeAndOrientation
        and drawSmileyFace. */
        randomizeSmileySizeAndOrientation();
        drawSmileyFace(locX, locY, size, makeRandomHeadColor(), makeRandomEyeColor(), makeRandomMouthColor(), g2d);

        randomizeSmileySizeAndOrientation();
        drawSmileyFace(locX, locY, size, makeRandomHeadColor(), makeRandomEyeColor(), makeRandomMouthColor(), g2d);

        randomizeSmileySizeAndOrientation();
        drawSmileyFace(locX, locY, size, makeRandomHeadColor(), makeRandomEyeColor(),makeRandomMouthColor(), g2d);

        randomizeSmileySizeAndOrientation();
        drawSmileyFace(locX, locY, size, makeRandomHeadColor(), makeRandomEyeColor(),makeRandomMouthColor(), g2d);

        randomizeSmileySizeAndOrientation();
        drawSmileyFace(locX, locY, size, makeRandomHeadColor(), makeRandomEyeColor(),makeRandomMouthColor(), g2d);

        randomizeSmileySizeAndOrientation();
        drawSmileyFace(locX, locY, size, makeRandomHeadColor(), makeRandomEyeColor(), makeRandomMouthColor(), g2d);

        randomizeSmileySizeAndOrientation();
        drawSmileyFace(locX, locY, size, makeRandomHeadColor(), makeRandomEyeColor(), makeRandomMouthColor(), g2d);
    }


    /**
     * This method assigns the variables size, locX, and locY to
     * random values pertaining to the origin and size of the
     * smiley faces.
     *
     */
    private void randomizeSmileySizeAndOrientation(){
        size = (int) (Min +Math.random() * (Max - Min) + 1);
        locX = (int)(Math.random()*(getWidth()-size))+1;
        locY = (int)(Math.random()*(getHeight()-size))+1;
    }


    /**
     * This method draws the smiley face and places the the nose and mouth on it.
     * @param locX The x-coordinate of the origin of the smiley face.
     * @param locY The y-coordinate of the origin of the smiley face.
     * @param size The size of the smiley face.
     * @param headColor Color of the head/face of the smiley face.
     * @param eyeColor Color of the eyes.
     * @param g2d Instance of graphics class after anti-aliasing.
     */
    private void drawSmileyFace(int locX, int locY, int size, Color headColor, Color eyeColor, Color mouthColor, Graphics2D g2d) {
        /*  This is a test line that prints the origin (locX, locY) and size of smiley face to the console to
        ensure that the smiley face does not exceed the bounds of the applet.  */
        System.out.println("locX: " + locX + " locY: " + locY + " Size: " + size);

        //This line sets the random head color of the smiley face.
        g2d.setColor(headColor);

        //Makes and fill in the head of the smiley face.
        g2d.fillOval(locX, locY, size, size);

        //This line sets the random color of the eyes.
        g2d.setColor(eyeColor);

        //Makes and fills in both eyes of the smiley face.
        g2d.fillOval(locX + size / 4, locY + size / 4, size / 8, size / 8);
        g2d.fillOval(13*size/20+locX, locY + size/4, size/8, size/8);

        //This line sets the random color of the mouth.
        g2d.setColor(mouthColor);

        //Make and fills in the mouth of the smiley face.
        g2d.fillArc(locX+size/4, locY + 7 *size/20, size/2, size/2, 180,180);

        //The color is set to white to outline the smiley face.
        g2d.setColor(Color.WHITE);

        //The head is outlined in white.
        g2d.drawOval(locX, locY, size, size);

        //Both of the eyes are outlined in white.
        g2d.drawOval(locX + size / 4, locY + size / 4, size / 8, size / 8);
        g2d.drawOval(13*size/20+locX, locY + size/4, size/8, size/8);

        //The mouth is outlined in white.
        g2d.drawArc(locX+size/4, locY + 7 *size/20, size/2, size/2, 180,180);
    }


    /**
     * This method generates random rgb values.
     * @return randomColor
     */
    private Color makeRandomColor(){
        int red = (int) (Math.random() * 255)+1;
        int green = (int) (Math.random() * 255)+1;
        int blue = (int) (Math.random() * 255)+1;
        Color randomColor = new Color(red, green, blue);
        return randomColor;
    }


    /**
     * This method makes the head of the smiley face a random color.
     * @return makeRandomColor()
     */
    private Color makeRandomHeadColor(){return makeRandomColor();}


    /**
     * This method makes the eyes of the smiley face a random color.
     * @return makeRandomColor()
     */
    private Color makeRandomEyeColor() {return makeRandomColor();}

    /**
     * This method makes the mouth of the smiley face a random color.
     *
     * I decided to add this third color method, as I thought that
     * having the same color for both the mouth and the eyes would
     * be kind of boring.
     *
     * @return makeRandomColor()
     */
    private Color makeRandomMouthColor(){return makeRandomColor();}
}
