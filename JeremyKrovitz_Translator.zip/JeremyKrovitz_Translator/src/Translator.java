import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Jeremy Krovitz
 * CSci 1130-91
 * Summer 2017
 *
 * This is the translator program that will allow the user to input an
 * English word and get the word returned translated into Spanish along
 * with a picture representing the word. If there is no translation
 * for the word input, an error message will be displayed in an image
 * along with an error message in the text field.
 */

public class Translator extends JApplet implements ActionListener {

    private String[] englishWords = {"error", "strawberry", "apple", "orange", "nectarine",
            "banana", "peach", "pear", "plum", "watermelon", "raspberry", "cherry"};

    private String[] spanishWords = {"el error", "la fresa", "la manzana", "la naranja",
            "la nectarina", "la banana", "el durazno", "la pera", "la ciruela", "la sandía",
            "la frambuesa", "la cereza"};

    private String[] namesOfImages={"error.png", "strawberry.png", "apple.png", "orange.png", "nectarine.png",
            "banana.png", "peach.png", "pear.png", "plum.png", "watermelon.png", "raspberry.png", "cherry.png"};


    private final int NUM_PICS=namesOfImages.length;
    private JTextField input;
    private JButton translate;
    private JLabel spanishOutputLabel, imageLabel;
    private Image[ ] photos;
    private ImageIcon icon;
    private String inputString;
    private JPanel inputsPanel, outputPanel;
    private int index;

    /**
     * This is the init method, which calls the method setsLayout on BorderLayout, initializes the photos array,
     * and calls the methods setUpImages, setupThePanels, initializeJLabelJTextFieldAndJButton, and
     * addJFieldJLabelJPanelAndActionListener.
     */
    public void init(){
        setLayout(new BorderLayout());
        photos=new Image[NUM_PICS];
        setupImages();
        setupThePanels();
        initializeJLabelJTextFieldAndJButton();
        addJFieldJLabelJPanelAndActionListener();
    }

    /**
     * This method will find the location of each of the images in the namesOfImages array.
     */
    private void setupImages(){
        for(int i=0; i<namesOfImages.length; i++){
            photos[i]=getImage(getCodeBase(), "Images/" + namesOfImages[i]);
        }
        getContentPane().setBackground(new Color(131, 232, 245)); //sets background color of the applet.
        icon = new ImageIcon( );
    }

    /**
     * This method initializes the inputsPanel and the outputPanel. It also sets the background
     * of the panel.
     */
    private void setupThePanels(){
        inputsPanel = new JPanel();
        outputPanel = new JPanel();
        outputPanel.setOpaque(true);
        outputPanel.setBackground(new Color(131, 232, 245)); //Sets color of panel.
    }

    /**
     * This method initializes the JTextField, input, the JButton, translate, and the output labels,
     * spanishOutputLabel, and imageLabel.
     */
    private void initializeJLabelJTextFieldAndJButton() {
        input = new JTextField(20);
        translate = new JButton("translate");
        spanishOutputLabel = new JLabel("");
        imageLabel = new JLabel(icon);
    }

    /**
     * This method makes the image appear when the button is pressed. 
     * @param index the index of the photo in the namesOfImages array. 
     */
    private void setupIcon( int index ) {
        icon.setImage(photos[index]);
        translate.setEnabled(true);
    }

    /**
     * This method adds the JField, JLabels, JPanels, and ActionListener to the applet. 
     */
    private void addJFieldJLabelJPanelAndActionListener(){
        translate.addActionListener(this);
        inputsPanel.add(input);
        inputsPanel.add(translate);
        add(inputsPanel);
        add(outputPanel);
        outputPanel.add(imageLabel);
        outputPanel.add(spanishOutputLabel);
        add(outputPanel, BorderLayout.WEST);
        add(inputsPanel, BorderLayout.NORTH);
    }

    /**
     * When the translate button is pressed, this method will execute. It calls the foundOrNotFound method. 
      * @param e this is an event
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == translate) {
            inputString = input.getText();
            foundOrNotFound();
        }
    }

    /***
     * This is the method that will check whether a Spanish translation for the English word
     * exists.
     */
    private void foundOrNotFound(){
        if(!inputString.equalsIgnoreCase("")) {
            index = findIndexOfString(inputString);
            if (index > -1) ifWordFound();
            else  ifWordNotFound();
        }
    }

    /**
     * This method contains a set of statements that will be executed if the word is found.
     */
    private void ifWordFound(){
            String spanishWord;
            spanishWord = spanishWords[index];
            spanishOutputLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
            spanishOutputLabel.setText(" The Spanish translation of " + inputString + '\n' + "is " + spanishWord + " and is found at index " + index + "!");
    }

    /**
     * This method contains a set of statements that will be executed if the word is not found.
     */
    private void ifWordNotFound(){
        icon.setImage(photos[0]);
        input.setText("Please enter a valid word!");
        spanishOutputLabel.setText(" ");
    }

    /**
     * This method returns the index at which the English word in the array englishWords is found.
     * @param input text put into the textfield.
     * @return -1
     */
    private int findIndexOfString (String input){
        int index = 0;
        while (index<englishWords.length){
            if(input.equalsIgnoreCase(englishWords[index])){// if found, return that index.
                int currentIndex;
                currentIndex = index;
                setupIcon(currentIndex);
                return index;
            }
            index ++;
        }
        return -1;
    }
}