import java.awt.*;
import javax.swing.*;
import java.util.Calendar;

/*
 * Jeremy Krovitz
 * Sci 1130-91
 * Summer 2017
 *
 * This is applet helps vacationers decide what
 * activities they should do depending on the
 * season and the temperature.
 *
 * I was running into all kinds of errors when
 * I would use the paint method with the pictures
 * added to teh program, so I decided to use a
 * JLabel instead.
 *
 * Rose-Gabriel Dillon and I got together to
 * work on this assignment. Though, I think
 * our assignments are very different
 * anyway.
 */

public class LakeLazyDayz extends JApplet {

    //I am declaring my instance variables here.
    private int month;
    private String nameOfMonth;
    private int intTemp;
    private String winterWeather;
    private String springSummerFallWeather;
    private String windyOrNotWindyWeather;
    private String nameOfSeason;


    /**
     * In the init() method we call several methods to initialize
     * the program.
     */
    public void init() {
        currentOrChoiceMonth();
        switchMonthSeasonTemp();
        setLayout(new FlowLayout());
    }


    /**
     * In this method I do the switch
     * statement, with a set of cases
     * representing each of the months
     * of the year. I start out at
     * case 1 and continue through
     * case 12 because I add '1' to
     * 'rightNow.get(Calendar.MONTH)'
     * in order to make it consistent
     * with the current month.
     */
    private void switchMonthSeasonTemp() {
        switch (month) {

            /*
             * These are the winter months.
             * They each contain a call to
             * the method IntWinterSwitchBlock
             * which is a method with the
             * same chunk of code that
             * will be executed for each of
             * these three months.
             */

            case 1:
                nameOfMonth = "January";
                nameOfSeason = "Winter";
                thisIsSomeMonthAndSeasonString();
                intWinterSwitchBlock();
                break;
            case 2:
                nameOfMonth = "February";
                nameOfSeason = "Winter";
                thisIsSomeMonthAndSeasonString();
                intWinterSwitchBlock();
                break;
            case 12:
                nameOfMonth = "December";
                nameOfSeason = "Winter";
                thisIsSomeMonthAndSeasonString();
                intWinterSwitchBlock();
                break;


            /*
             * These are the spring months.
             * They each contain a call to
             * the method IntSpringSwitchBlock
             * which is a method with the
             * same chunk of code that
             * will be executed for each of
             * these three months.
             */

            case 3:
                nameOfMonth = "March";
                nameOfSeason = "Spring";
                thisIsSomeMonthAndSeasonString();
                intSpringSwitchBlock();
                break;
            case 4:
                nameOfMonth = "April";
                nameOfSeason = "Spring";
                thisIsSomeMonthAndSeasonString();
                intSpringSwitchBlock();
                break;
            case 5:
                nameOfMonth = "May";
                nameOfSeason = "Spring";
                thisIsSomeMonthAndSeasonString();
                intSpringSwitchBlock();
                break;

            /*
             * These are the summer months.
             * They each contain a call to
             * the method IntSummerSwitchBlock
             * which is a method with the
             * same chunk of code that
             * will be executed for each of
             * these three months.
             */

            case 6:
                nameOfMonth = "June";
                nameOfSeason = "Summer";
                thisIsSomeMonthAndSeasonString();
                intSummerSwitchBlock();
                break;
            case 7:
                nameOfMonth = "July";
                nameOfSeason = "Summer";
                thisIsSomeMonthAndSeasonString();
                intSummerSwitchBlock();
                break;
            case 8:
                nameOfMonth = "August";
                nameOfSeason = "Summer";
                thisIsSomeMonthAndSeasonString();
                intSummerSwitchBlock();
                break;

            /*
             * These are the fall months.
             * They each contain a call to
             * the method IntFallSwitchBlock
             * which is a method with the
             * same chunk of code that
             * will be executed for each of
             * these three months.
             */

            case 9:
                nameOfMonth = "September";
                nameOfSeason = "Fall";
                thisIsSomeMonthAndSeasonString();
                intFallSwitchBlock();
                break;
            case 10:
                nameOfMonth = "October";
                nameOfSeason = "Fall";
                thisIsSomeMonthAndSeasonString();
                intFallSwitchBlock();
                break;
            case 11:
                nameOfMonth = "November";
                nameOfSeason = "Fall";
                thisIsSomeMonthAndSeasonString();
                intFallSwitchBlock();
                break;
        }
    }


    /**
     * This method will call getCurrentMonth() if a
     * user wants to find an activity to do based on
     * the month right now. It also calls get another
     * month if the user wants to find an activity to
     * do in the future.
     */
    private void currentOrChoiceMonth() {
        String userInput;
        userInput = JOptionPane.showInputDialog(this, "For the current month, " +
                "please input 'current month' or input a random key to be prompted to choose another month.");
        if (userInput.equalsIgnoreCase("current month")) {
            getCurrentMonth();
        } else getAnotherMonth();
    }

    /**
     * This method uses the Calendar
     * class to determine the time
     * of the year as well as the
     * current month.
     */
    private void getCurrentMonth() {
        Calendar rightNow;
        rightNow = Calendar.getInstance();
        month = ((rightNow.get(Calendar.MONTH)) + 1);
    }


    /**
     * This method returns another month of the
     * year.
     */
    private void getAnotherMonth() {
        String stringMonth;
        stringMonth = JOptionPane.showInputDialog(this, "Input an integer " +
                "corresponding with the month (ex. input '6' for 'June'). ");
        month = Integer.parseInt(stringMonth);
        if (month < 1 || month >= 13) {
            JOptionPane.showMessageDialog(this, "Please enter a valid month.");
        }
    }

    /**
     * This method uses an input dialog box to get the temperature
     * from the user and then converts it into an integer.
     */
    private void getTemperatureInput() {
        String stringTemp;
        stringTemp = JOptionPane.showInputDialog(this, "What is the " +
                "temperature?" + '\n' + "(If it's winter, enter -30 to 39." + '\n' + "If it's spring, " +
                "enter 40 to 79." + '\n' + "If it's summer, enter 60 to 99." + '\n' + "If it's fall " +
                "enter 30 to 79.)");
        intTemp = Integer.parseInt(stringTemp);
    }

    /**
     * This method tells the user what month and season
     * it is.
     */
    private void thisIsSomeMonthAndSeasonString() {
        JOptionPane.showMessageDialog(this,
                "The month is " + nameOfMonth + '\n' +
                        "The season is: " + nameOfSeason + ".");
    }

    /**
     * The winter temperature conditional
     * statements.
     */
    private void intWinterSwitchBlock() {
        getTemperatureInput();

        if (intTemp <=0 && intTemp >= -30){
            getReallyColdWinterWeatherInputs();
        }

        if (intTemp >= 0 && intTemp < 30) {
            {
                winterWeatherCondtions();
                getColderWinterWeatherInputs();

            }
        }
        if (intTemp >= 30 && intTemp < 40) {
            winterWeatherCondtions();
            getWarmerWinterWeatherInputs();


        }

        while (intTemp < -30 || intTemp >= 40)

        {
            invalidTemperatureMessage();
            intWinterSwitchBlock();
        }
    }

    /**
     * The spring temperature conditional
     * statements.
     */
    private void intSpringSwitchBlock() {
        getTemperatureInput();
        if (intTemp >= 40 && intTemp < 60) {
            springSummerFallWeatherConditions();
            getColderSpringWeatherInputs();

        }
        if (intTemp >= 60 && intTemp < 80) {
            springSummerFallWeatherConditions();
            getWarmerSpringWeatherInputs();

        }
        while (intTemp < 40 || intTemp >= 80) {
            invalidTemperatureMessage();
            intSpringSwitchBlock();
        }
    }

    /**
     * The summer temperature conditional
     * statements.
     */
    private void intSummerSwitchBlock() {
        getTemperatureInput();
        if (intTemp >= 60 && intTemp < 80) {
            springSummerFallWeatherConditions();
            getColderSummerWeatherInputs();

        }
        if (intTemp >= 80 && intTemp < 100) {
            springSummerFallWeatherConditions();
            getWarmerSummerWeatherInputs();

        }
        while (intTemp < 60 || intTemp >= 100) {
            invalidTemperatureMessage();
            intSummerSwitchBlock();
        }
    }

    /**
     * The summer temperature conditional
     * statements.
     */
    private void intFallSwitchBlock() {
        getTemperatureInput();
        if (intTemp >= 30 && intTemp < 60) {
            springSummerFallWeatherConditions();
            getColderFallWeatherInputs();

        }
        if (intTemp >= 60 && intTemp < 80) {
            windyOrNotWindyWeatherConditions();
            getWarmerFallWeatherInputs();

        }
        while (intTemp < 30 || intTemp >= 80) {
            invalidTemperatureMessage();
            intFallSwitchBlock();
        }


    }

    /**
     * This method describes the winter weather conditions
     * and makes the user re-enter the condition if the
     * wrong condition is input.
     */
    private void winterWeatherCondtions() {
        winterWeather = JOptionPane.showInputDialog(this, "Is it sunny or " +
                "snowy? (Literally type 'sunny' or 'snowy'.)");
        while (!(winterWeather.equalsIgnoreCase("sunny") ||
                winterWeather.equalsIgnoreCase("snowy"))) {
            invalidWeatherConditionMessage();
            winterWeatherCondtions();
        }
    }

    /**
     * This method describes the spring,
     * summer, and fall weather conditions since
     * it can be sunny or rainy in all three seasons.
     * The method makes the user re-enter the condition if the
     * wrong condition is input.
     */
    private void springSummerFallWeatherConditions() {
        springSummerFallWeather = JOptionPane.showInputDialog(this,
                "Is it sunny or rainy?");
        while (!(springSummerFallWeather.equalsIgnoreCase("sunny") ||
                springSummerFallWeather.equalsIgnoreCase("rainy"))) {
            invalidWeatherConditionMessage();
            springSummerFallWeatherConditions();
        }
    }

    /**
     * This method describes whether it's windy out
     * or not and makes the user re-enter the
     * condition if the
     * wrong condition is input.
     */
    private void windyOrNotWindyWeatherConditions(){
        windyOrNotWindyWeather = JOptionPane.showInputDialog(this,
                "Is it windy or not windy?");
        while (!(windyOrNotWindyWeather.equalsIgnoreCase("windy")||
                windyOrNotWindyWeather.equalsIgnoreCase("not windy"))){
            invalidWeatherConditionMessage();
            windyOrNotWindyWeatherConditions();

        }
    }

    /**
     * This method adds the JOptionPane, the JLabel, and calls the setUpImage method
     * based on the specific weather conditions associated with warmer winter
     * weather.
     */
    private void getWarmerWinterWeatherInputs() {
        if (winterWeather.equalsIgnoreCase("sunny")) {
            JOptionPane.showMessageDialog(this, "Let's go sledding!");
            setupImage("sledding.jpg");
            JLabel sledLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =3> " +
                    "I love sledding, especially when it isn't as cold out!", JLabel.LEFT);
            add(sledLabel);

        }
        if (winterWeather.equalsIgnoreCase("snowy")) {
            JOptionPane.showMessageDialog(this, "You should go skiing!");
            setupImage("skiing.jpg");
            JLabel skiingLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> " +
                    "I love skiing!", JLabel.LEFT);
            add(skiingLabel);
        }

    }

    /**
     * This method adds the JOptionPane, the JLabel, and calls the setUpImage method
     * based on the specific weather conditions associated with colder winter
     * weather.
     */
    private void getColderWinterWeatherInputs() {
        if (winterWeather.equalsIgnoreCase("sunny")){
            JOptionPane.showMessageDialog(this, "Let's go skating!");
            setupImage("skating.jpg");
            JLabel skatingLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> I'm " +
                    "really bad at skating. I have horrible balance, but you might like it!",
                    JLabel.LEFT);
            add(skatingLabel);
        }
        else if (winterWeather.equalsIgnoreCase("snowy")){
            JOptionPane.showMessageDialog(this, "Let's go snowmobiling!");
            setupImage("snowmobile.jpg");
            JLabel snowMobileLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> " +
                    "Snowmobiles are too noisy for me, but some like them." +
                    JLabel.LEFT);
            add(snowMobileLabel);

        }
    }

    /**
     * This method adds the JOptionPane, the JLabel, and calls the setUpImage method
     * associated with really cold winter weather.
     */
    private void getReallyColdWinterWeatherInputs() {
        JOptionPane.showMessageDialog(this, "Bundle up if outside. " +
                "Try to stay inside as much as possible!");
        setupImage("bundledUp.jpg");
        JLabel coldLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> It doesn't" +
                "matter whether it's sunny or snowy. It's just cold.",
                JLabel.LEFT);
        add(coldLabel);
    }

    /**
     * This method adds the JOptionPane, the JLabel, and calls the setUpImage method
     * based on the specific weather conditions associated with colder spring
     * weather.
     */
    private void getColderSpringWeatherInputs() {
        if (springSummerFallWeather.equalsIgnoreCase("sunny")){
            JOptionPane.showMessageDialog(this, "Let's take a walk!");
            setupImage("aWalk.jpg");
            JLabel walksLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> Walks are " +
                    "always great, and it's a beautiful day for it.", JLabel.LEFT);
            add(walksLabel);
        }
        else if (springSummerFallWeather.equalsIgnoreCase("rainy")){//7
            JOptionPane.showMessageDialog(this, "Let's go to the mall!");
            setupImage("theMall.jpg");
            JLabel mallLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =+1> I love" +
                    " going to the mall", JLabel.CENTER);
            add(mallLabel);
        }
    }

    /**
     * This method adds the JOptionPane, the JLabel, and calls the setUpImage method
     * based on the specific weather conditions associated with warmer spring
     * weather.
     */
    private void getWarmerSpringWeatherInputs() {
        if (springSummerFallWeather.equalsIgnoreCase("sunny")){
            JOptionPane.showMessageDialog(this, "Let's swing on the Leonard " +
                    "Center Swing Set!");
            getContentPane().setBackground(new Color(80, 219, 255));
            setupImage("leonardCenterSwingSet.jpg");//8
            JLabel leonardCenterSwingSetLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT " +
                    "SIZE =5> You might even cruise over to Macalester and swing on that Leonard " +
                    "Center Swing Set.", JLabel.LEFT);
            add(leonardCenterSwingSetLabel);
        }

        if (springSummerFallWeather.equalsIgnoreCase("rainy")){
            JOptionPane.showMessageDialog(this, "Let's see a movie!");
            getContentPane().setBackground(new Color(30, 76, 155));
            setupImage("movieTheater.jpg");//9
            JLabel movieLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> Let's " +
                    "go see a movie.", JLabel.LEFT);
            add(movieLabel);
        }
    }

    /**
     * This method adds the JOptionPane, the JLabel, and calls the setUpImage method
     * based on the specific weather conditions associated with cooler summer
     * weather.
     */
    private void getColderSummerWeatherInputs() {
        if (springSummerFallWeather.equalsIgnoreCase("sunny")){
            JOptionPane.showMessageDialog(this, "Let's fly a kite!");//10
            getContentPane().setBackground(new Color(7, 208, 226));
            setupImage("flyKite.jpg");
            JLabel kiteLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> " +
                    "There's nothing better to do on a summer day when it's not very warm out " +
                    "than flying a kite!", JLabel.LEFT);
            add(kiteLabel);
        }
        if (springSummerFallWeather.equalsIgnoreCase("rainy")){
            JOptionPane.showMessageDialog(this, "Let's go to the zoo!");
            getContentPane().setBackground(new Color(200, 201, 61));
            setupImage("zoo.jpg");
            JLabel zooLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> With all " +
                    "of the animals here, you'd think this was a zoo or something.", JLabel.LEFT);
            add(zooLabel);
        }
    }

    /**
     * This method adds the JOptionPane, the JLabel, and calls the setUpImage method
     * based on the specific weather conditions associated with warmer summer
     * weather.
     */
    private void getWarmerSummerWeatherInputs() {
        if (springSummerFallWeather.equalsIgnoreCase("sunny")) {
            JOptionPane.showMessageDialog(this, "Let's go to the beach!");
            getContentPane().setBackground(new Color(30, 76, 155));
            setupImage("theBeach.jpg");
            JLabel beachLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> Vamos " +
                    "a la playa!!!", JLabel.LEFT);
            add(beachLabel);
        }
        if (springSummerFallWeather.equalsIgnoreCase("rainy")){
            JOptionPane.showMessageDialog(this, "Let's go to an indoor pool!");
            getContentPane().setBackground(new Color(30, 76, 155));
            setupImage("indoorPool.jpg");
            JLabel poolLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> Yeah," +
                    " it's not as great as going to the outdoor pool, but at least we're cooling " +
                    "off a bit", JLabel.LEFT);
            add(poolLabel);
        }
    }

    /**
     * This method adds the JOptionPane, the JLabel, and calls the setUpImage method
     * based on the specific weather conditions associated with cooler fall weather
     * weather.
     */
    private void getColderFallWeatherInputs() {
        if (springSummerFallWeather.equalsIgnoreCase("sunny")){
            JOptionPane.showMessageDialog(this, "Let's go to an apple orchard!");//14
            getContentPane().setBackground(new Color(155, 137, 53));
            setupImage("appleOrchard.jpg");
            JLabel appleOrchardLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5>" +
                    "I love going to the apple orchard, especially during Rosh Hashanah time!",
                    JLabel.LEFT);
            add(appleOrchardLabel);
        }

        if (springSummerFallWeather.equalsIgnoreCase("rainy")){
            JOptionPane.showMessageDialog(this, "Let's stay inside and bake " +
                    "cookies!");
            getContentPane().setBackground(new Color(101, 155, 146));
            setupImage("bakeCookies.jpg");
            JLabel cookieLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5> Freshly baked" +
                    " cookies sound great right now!", JLabel.LEFT);
            add(cookieLabel);
        }
    }

    /**
     * This method adds the JOptionPane, the JLabel, and calls the setUpImage method
     * based on the specific weather conditions associated with warmer fall
     * weather.
     */
    private void getWarmerFallWeatherInputs() {
        if (windyOrNotWindyWeather.equalsIgnoreCase("not windy")){
            JOptionPane.showMessageDialog(this, "Let's go to a pumpkin patch!");
            getContentPane().setBackground(new Color(179, 233, 106));
            setupImage("pumpkinPatch.jpg");
            JLabel pumpkinPatchLabel = new JLabel("<HTML><FONT COLOR =BLACK><FONT SIZE =5> " +
                    "It's a nice day for pumpkin carving!", JLabel.LEFT);
            add(pumpkinPatchLabel);
        }

        if (windyOrNotWindyWeather.equalsIgnoreCase("windy")){
            JOptionPane.showMessageDialog(this, "Let's go golfing!");
            getContentPane().setBackground(new Color(89, 212, 245));
            setupImage("golf.jpg");
            JLabel golfLabel = new JLabel("<HTML><FONT COLOR = WHITE><FONT SIZE =5>I don't golf, " +
                    "but I hear a lot of people like it, so why not?", JLabel.LEFT);
            add(golfLabel);
        }
    }

    /**
     * This method gives the user a message that the temperature typed in is invalid.
     */
    private void invalidTemperatureMessage(){
        JOptionPane.showMessageDialog(this, "That seems like an invalid " +
                "temperature for this season.");
    }


    /**
     * This method gives the user a message that the weather condition typed in is invalid.
     */
    private void invalidWeatherConditionMessage(){
        JOptionPane.showMessageDialog(this, "That was an invalid " +
                "weather condition. Please try again.");
    }

    /**
     * This method is where the JLabels for
     * both images and text get created.
     * This method gets called in other methods.
     * @param myImage this is the image object.
     */
    private void setupImage(String myImage) {
        Image img;
        ImageIcon ic;
        JLabel Lab;
        img = getImage(getCodeBase(), myImage);
        ic = new ImageIcon(img);
        Lab = new JLabel(ic);
        add(Lab);
    }
}